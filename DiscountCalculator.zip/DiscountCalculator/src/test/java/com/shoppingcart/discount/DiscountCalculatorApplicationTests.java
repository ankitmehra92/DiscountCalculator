package com.shoppingcart.discount;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.shoppingcart.discount.Controller.BillController;
import com.shoppingcart.discount.Service.BillService;

@WebMvcTest(controllers = BillController.class)
class DiscountCalculatorApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private BillService service;
	
	@MockBean
	private BillController controller;

	@Test
	public void getDiscount() throws Exception
	{
		this.mockMvc.perform(post("/billing")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\n" + 
				"    \"type\":\"PREMIUM\",\n" + 
				"    \"amount\":3500\n" + 
				"}").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print());
	}

}
