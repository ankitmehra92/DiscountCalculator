package com.shoppingcart.discount.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class APIResponse 
{
	private double billAmount;
	
	public APIResponse(double billAmount) {
		super();
		this.billAmount = billAmount;
	}

	@JsonProperty("billamount")
	public double getBillAmount() {
		return billAmount;
	}

	@JsonProperty("billamount")
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	} 
	
	

}
