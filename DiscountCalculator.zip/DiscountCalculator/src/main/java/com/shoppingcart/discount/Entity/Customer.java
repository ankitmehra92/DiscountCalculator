package com.shoppingcart.discount.Entity;

public interface Customer 
{
	public String getType();
}
