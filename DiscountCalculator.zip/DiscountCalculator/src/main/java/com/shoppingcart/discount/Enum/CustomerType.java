package com.shoppingcart.discount.Enum;

public enum CustomerType 
{
	PREMIUM("Premium"),
	REGULAR("Regular");
	
	public final String type;
	
	private CustomerType(String type)
	{
		this.type = type;
	}
	
}
