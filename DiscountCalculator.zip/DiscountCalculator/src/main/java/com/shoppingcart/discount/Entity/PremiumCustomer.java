package com.shoppingcart.discount.Entity;

import com.shoppingcart.discount.Enum.CustomerType;

public class PremiumCustomer implements Customer {

	private CustomerType type;

	public PremiumCustomer(CustomerType type) {
		super();
		this.type = type;
	}

	@Override
	public String getType() {
		return this.type.toString();
	}
	
	public void setType(CustomerType type) {
		this.type = type;
	}
}
