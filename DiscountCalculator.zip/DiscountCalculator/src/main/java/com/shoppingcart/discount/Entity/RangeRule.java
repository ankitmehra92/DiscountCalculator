package com.shoppingcart.discount.Entity;

public class RangeRule implements Comparable<RangeRule>
{
	private double low;
	private double high;
	private double discount;
	
	public double getLow() {
		return low;
	}
	public void setLow(double low) {
		this.low = low;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	
	
	@Override
	public String toString() {
		return "RangeRule [low=" + low + ", high=" + high + ", discount=" + discount + "]";
	}
	/*Implementing CompareTo for Natural Sorting*/
	@Override
	public int compareTo(RangeRule rule) {
		if (this.getLow() == rule.getLow()) {
            return 0;
        } else if (this.getLow() > rule.getLow()) {
            return 1;
        } else {
            return -1;
        }
	}
	
	public RangeRule(double low, double high, double discount) {
		super();
		this.low = low;
		this.high = high;
		this.discount = discount;
	}
	
}
