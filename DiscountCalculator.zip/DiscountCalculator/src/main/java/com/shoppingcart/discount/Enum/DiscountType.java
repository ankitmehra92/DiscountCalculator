package com.shoppingcart.discount.Enum;

public enum DiscountType {

	REGULAR,PREMIUM;
}
