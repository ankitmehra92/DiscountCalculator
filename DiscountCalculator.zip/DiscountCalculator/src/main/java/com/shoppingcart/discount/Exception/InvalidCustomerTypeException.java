package com.shoppingcart.discount.Exception;

public class InvalidCustomerTypeException extends Exception {

}
