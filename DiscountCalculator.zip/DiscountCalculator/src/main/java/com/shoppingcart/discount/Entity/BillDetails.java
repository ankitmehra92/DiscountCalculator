package com.shoppingcart.discount.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BillDetails 
{

	private String customerType;
	private double cartAmount;
	
	@JsonProperty("type")
	public String getCustomerType() {
		return customerType;
	}
	
	@JsonProperty("type")
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	
	@JsonProperty("amount")
	public double getCartAmount() {
		return cartAmount;
	}
	
	@JsonProperty("amount")
	public void setCartAmount(double cartAmount) {
		this.cartAmount = cartAmount;
	}

}
