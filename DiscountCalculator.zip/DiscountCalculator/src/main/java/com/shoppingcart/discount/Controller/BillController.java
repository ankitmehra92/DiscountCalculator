package com.shoppingcart.discount.Controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.discount.Entity.APIResponse;
import com.shoppingcart.discount.Entity.BillDetails;
import com.shoppingcart.discount.Entity.Customer;
import com.shoppingcart.discount.Enum.CustomerType;
import com.shoppingcart.discount.Exception.InvalidCustomerTypeException;
import com.shoppingcart.discount.Exception.NegativeBillAmountException;
import com.shoppingcart.discount.FactoryImpl.CustomerFactory;
import com.shoppingcart.discount.Service.BillService;

@RestController
public class BillController 
{
	@Autowired
	BillService service;

	@RequestMapping(path = "/billing",method = RequestMethod.POST)
	public ResponseEntity<APIResponse> getFinalBillValue(@RequestBody BillDetails details) throws NegativeBillAmountException, InvalidCustomerTypeException
	{
		if(details.getCartAmount() < 0)
			throw new NegativeBillAmountException();
		
		long count = Arrays.asList(CustomerType.values()).parallelStream().filter(custType -> custType.type.equals(details.getCustomerType())).count();
		
		if(count<1)
			throw new InvalidCustomerTypeException();
		
		CustomerFactory factory = new CustomerFactory();
		Customer customer = factory.getCustomer(details.getCustomerType());
		Double finalAmount = service.getFinalAmount(customer,details.getCartAmount());
		APIResponse response = new APIResponse(finalAmount);
		return new ResponseEntity<APIResponse>(response, HttpStatus.OK);
	}
	

}
