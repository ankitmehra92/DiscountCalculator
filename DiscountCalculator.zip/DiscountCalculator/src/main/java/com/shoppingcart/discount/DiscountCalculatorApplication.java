package com.shoppingcart.discount;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.shoppingcart.discount.Entity.RangeRule;
import com.shoppingcart.discount.Enum.DiscountType;

@SpringBootApplication
public class DiscountCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscountCalculatorApplication.class, args);
	}
	

	@Bean(name = "DiscountMappings")
	public Map<String,List<RangeRule>> populate()
	{
		Map<String,List<RangeRule>> discountMap = new HashMap<String,List<RangeRule>>();
		
		for (DiscountType discountType : DiscountType.values()) {
			discountMap.put(discountType.toString(),new ArrayList<RangeRule>());
		}
		
		
		/**
		 * HardCode for populating the discount Details, these details could be externalize through properties 
		 * file or DB Call for for more dynamic behavior
		 * 
		 * */
		
		List<RangeRule> ruleList = discountMap.get(DiscountType.REGULAR.toString());
		RangeRule rule = new RangeRule(0,5000,0);
		ruleList.add(rule);
		rule = new RangeRule(5001,10000,10);
		ruleList.add(rule);
		rule = new RangeRule(10000,Double.MAX_VALUE,20);
		ruleList.add(rule);
		
		ruleList =discountMap.get(DiscountType.PREMIUM.toString());
		rule = new RangeRule(0,4000,10);
		ruleList.add(rule);
		rule = new RangeRule(4001,8000,15);
		ruleList.add(rule);
		rule = new RangeRule(8001,12000,20);
		ruleList.add(rule);
		rule = new RangeRule(12001,Double.MAX_VALUE,30);
		ruleList.add(rule);
		
		return discountMap;
	}
}
