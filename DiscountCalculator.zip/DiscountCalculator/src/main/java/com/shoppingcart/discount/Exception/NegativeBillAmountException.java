package com.shoppingcart.discount.Exception;

public class NegativeBillAmountException extends Exception {

}
