package com.shoppingcart.discount.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shoppingcart.discount.Entity.Customer;
import com.shoppingcart.discount.Entity.RangeRule;

@Service
public class BillService {
	
	@Autowired
	@Qualifier("DiscountMappings")
	Map<String,List<RangeRule>> discountmappings;
	public double getFinalAmount(Customer customer,double amount)
	{
		List<RangeRule> ruleList  = discountmappings.get(customer.getType());
		RangeRule selectRule = ruleList.parallelStream().filter(rule -> {return rule.getLow()<=amount && amount<=rule.getHigh();}).collect(Collectors.toList()).get(0);
		double rate = selectRule.getDiscount();
		return (double)(amount - ((amount*rate)/100));
	}
}
