package com.shoppingcart.discount.FactoryImpl;

import com.shoppingcart.discount.Entity.Customer;
import com.shoppingcart.discount.Entity.PremiumCustomer;
import com.shoppingcart.discount.Entity.RegularCustomer;
import com.shoppingcart.discount.Enum.CustomerType;

public class CustomerFactory {
	public Customer getCustomer(String customerType) {
		if (customerType == null || customerType.isEmpty())
			return null;
		switch (customerType) {
		case "REGULAR":
			return new RegularCustomer(CustomerType.REGULAR);
		case "PREMIUM":
			return new PremiumCustomer(CustomerType.PREMIUM);
		default:
			throw new IllegalArgumentException("InValid Customer type" + customerType);
		}
	}

}
