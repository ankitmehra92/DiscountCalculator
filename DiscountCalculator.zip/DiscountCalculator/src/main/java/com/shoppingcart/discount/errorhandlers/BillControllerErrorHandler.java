package com.shoppingcart.discount.errorhandlers;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.shoppingcart.discount.Exception.InvalidCustomerTypeException;
import com.shoppingcart.discount.Exception.NegativeBillAmountException;

@ControllerAdvice
public class BillControllerErrorHandler extends ResponseEntityExceptionHandler
{
	@ExceptionHandler(InvalidCustomerTypeException.class)
	public ResponseEntity<Object> handleInvalidCustomerTypeException(
	    InvalidCustomerTypeException ex, WebRequest request) {

	    Map<String, Object> body = new LinkedHashMap<String, Object>();
	    body.put("timestamp", LocalDateTime.now());
	    body.put("message", "Invalid Customer Type");

	    return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(NegativeBillAmountException.class)
	public ResponseEntity<Object> handleNegativeBillAmountException(
			NegativeBillAmountException ex, WebRequest request) {

	    Map<String, Object> body = new LinkedHashMap<String, Object>();
	    body.put("timestamp", LocalDateTime.now());
	    body.put("message", "Bill Amount Cant be negative");

	    return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

}
